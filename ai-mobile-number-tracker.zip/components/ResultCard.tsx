
import React from 'react';
import type { TrackingResult } from '../types';
import { GlobeAltIcon, WifiIcon, ClockIcon, MapPinIcon, CheckCircleIcon, XCircleIcon } from './icons/Icons';

interface ResultCardProps {
  data: TrackingResult;
}

const InfoRow: React.FC<{ icon: React.ReactNode; label: string; value: string | string[] }> = ({ icon, label, value }) => (
  <div className="flex items-start py-3 border-b border-slate-700 last:border-b-0">
    <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center text-cyan-400">{icon}</div>
    <div className="ml-4">
      <p className="text-sm font-semibold text-slate-400">{label}</p>
      <p className="text-lg text-white font-medium">
        {Array.isArray(value) ? value.join(', ') : value}
      </p>
    </div>
  </div>
);

const ResultCard: React.FC<ResultCardProps> = ({ data }) => {
  return (
    <div className="w-full bg-slate-800/70 rounded-xl shadow-lg p-6 border border-slate-700 animate-fade-in">
      <div className="flex items-center justify-between pb-4 border-b border-slate-700 mb-2">
        <h2 className="text-2xl font-bold text-white">Tracking Results</h2>
        {data.isValid ? (
          <div className="flex items-center gap-2 text-green-400 bg-green-900/50 px-3 py-1 rounded-full text-sm">
            <CheckCircleIcon className="w-5 h-5" />
            <span>Valid Number</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-red-400 bg-red-900/50 px-3 py-1 rounded-full text-sm">
            <XCircleIcon className="w-5 h-5" />
            <span>Invalid Number</span>
          </div>
        )}
      </div>

      {data.isValid && (
        <div className="divide-y divide-slate-700">
           <div className="flex items-center py-3">
             <div className="text-5xl mr-4">{data.flagEmoji}</div>
             <div>
                <p className="text-sm font-semibold text-slate-400">Country</p>
                <p className="text-2xl text-white font-bold">{data.country} ({data.countryCode})</p>
             </div>
           </div>
          <InfoRow icon={<WifiIcon className="w-6 h-6" />} label="Carrier" value={data.carrier} />
          <InfoRow icon={<ClockIcon className="w-6 h-6" />} label="Timezones" value={data.timezones} />
          <InfoRow icon={<MapPinIcon className="w-6 h-6" />} label="Geographic Location" value={data.location} />
        </div>
      )}
      {!data.isValid && (
        <div className="text-center py-8 text-slate-400">
          <p>The provided phone number could not be validated.</p>
          <p>Please check the number and try again.</p>
        </div>
      )}
    </div>
  );
};

export default ResultCard;
