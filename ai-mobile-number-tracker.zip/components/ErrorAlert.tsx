
import React from 'react';
import { XCircleIcon } from './icons/Icons';

interface ErrorAlertProps {
  message: string;
}

const ErrorAlert: React.FC<ErrorAlertProps> = ({ message }) => {
  return (
    <div className="w-full bg-red-900/50 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative flex items-center gap-3 animate-fade-in" role="alert">
      <XCircleIcon className="w-6 h-6 flex-shrink-0" />
      <div>
        <strong className="font-bold">Error: </strong>
        <span className="block sm:inline">{message}</span>
      </div>
    </div>
  );
};

export default ErrorAlert;
