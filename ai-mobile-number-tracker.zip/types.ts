
export interface TrackingResult {
  isValid: boolean;
  country: string;
  countryCode: string;
  flagEmoji: string;
  carrier: string;
  timezones: string[];
  location: string;
}
