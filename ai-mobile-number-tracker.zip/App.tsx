
import React, { useState, useCallback } from 'react';
import type { TrackingResult } from './types';
import { trackPhoneNumber } from './services/geminiService';
import ResultCard from './components/ResultCard';
import Loader from './components/Loader';
import ErrorAlert from './components/ErrorAlert';
import { PhoneIcon, SearchIcon } from './components/icons/Icons';

const App: React.FC = () => {
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [result, setResult] = useState<TrackingResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleTrackNumber = useCallback(async () => {
    if (!phoneNumber) {
      setError('Please enter a phone number.');
      return;
    }
    // Basic validation for country code
    if (!phoneNumber.startsWith('+')) {
      setError('Please include the country code (e.g., +1 555-123-4567).');
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const trackingData = await trackPhoneNumber(phoneNumber);
      setResult(trackingData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [phoneNumber]);

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleTrackNumber();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-2xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600">
            AI Mobile Number Tracker
          </h1>
          <p className="text-slate-400 mt-2 text-lg">
            Instantly get insights about any phone number using generative AI.
          </p>
        </header>

        <main className="bg-slate-800/50 p-6 rounded-2xl shadow-2xl border border-slate-700 backdrop-blur-sm">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <PhoneIcon className="h-5 w-5 text-slate-400" />
              </div>
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="+1 555-123-4567"
                className="w-full bg-slate-900 border border-slate-600 text-white placeholder-slate-500 rounded-lg py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all duration-300"
                disabled={isLoading}
              />
            </div>
            <button
              onClick={handleTrackNumber}
              disabled={isLoading}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold py-3 px-6 rounded-lg hover:from-cyan-600 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-cyan-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader />
                  <span>Tracking...</span>
                </>
              ) : (
                <>
                  <SearchIcon className="h-5 w-5" />
                  <span>Track Number</span>
                </>
              )}
            </button>
          </div>
          
          <div className="mt-6 min-h-[200px] flex items-center justify-center">
            {error && <ErrorAlert message={error} />}
            {isLoading && !error && (
                 <div className="text-center text-slate-400">
                    <p>AI is analyzing the number...</p>
                    <p className="text-sm mt-1">This may take a few seconds.</p>
                 </div>
            )}
            {result && !isLoading && <ResultCard data={result} />}
          </div>
        </main>
        
        <footer className="text-center mt-8 text-slate-500 text-sm">
          <p>Powered by Google Gemini. For informational purposes only.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
