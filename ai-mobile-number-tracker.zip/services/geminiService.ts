
import { GoogleGenAI, Type } from "@google/genai";
import type { TrackingResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    isValid: { type: Type.BOOLEAN },
    country: { type: Type.STRING },
    countryCode: { type: Type.STRING },
    flagEmoji: { type: Type.STRING },
    carrier: { type: Type.STRING },
    timezones: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    location: { type: Type.STRING },
  },
  required: ['isValid', 'country', 'countryCode', 'flagEmoji', 'carrier', 'timezones', 'location']
};

export const trackPhoneNumber = async (phoneNumber: string): Promise<TrackingResult> => {
  const prompt = `
    You are a phone number analysis expert. Given the following phone number, provide details about it.
    Phone number: "${phoneNumber}"

    Your response MUST be a single JSON object that conforms to the provided schema.
    Do not include any text, markdown, or code block syntax before or after the JSON object.

    If the phone number appears invalid, set "isValid" to false and the other fields to "N/A" or an empty array for timezones.
    For "location", provide the most specific information available (e.g., city or region). If not available, use "N/A".
    For "carrier", provide the name of the network provider. If not available, use "N/A".
    For "countryCode", provide the ISO 3166-1 alpha-2 code.
    For "flagEmoji", provide the corresponding Unicode flag emoji for the country.
  `;

  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("The AI returned an empty response. The phone number might be invalid.");
    }
    
    // Sometimes the model might still wrap the JSON in markdown
    const cleanedJsonText = jsonText.replace(/^```json\n?/, '').replace(/\n?```$/, '');
    
    const parsedResult = JSON.parse(cleanedJsonText) as TrackingResult;
    return parsedResult;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Could not retrieve tracking information. The number might be invalid or there was an issue with the AI service.");
  }
};
